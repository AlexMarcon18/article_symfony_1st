CREATE TABLE categories( 
   Id_cat Integer primary key AUTO_INCREMENT, 
   nom_cat VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE auteur(
   id_au Integer primary key AUTO_INCREMENT,
   nom_au VARCHAR(50) NOT NULL UNIQUE,
   prenom_au VARCHAR(50) NOT NULL UNIQUE,
   date_au DATE NOT NULL,
   contact_au VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE article( 
   id_a Integer primary key AUTO_INCREMENT,
   titre_a VARCHAR(50) NOT NULL,
   content_a TEXT NOT NULL,
   date_a DATE NOT NULL,
   id_au INT NOT NULL,
   FOREIGN KEY(id_au) REFERENCES auteur(id_au)
);

CREATE TABLE Appartient(
   Id_cat INT,
   id_a INT,
   PRIMARY KEY(Id_cat, id_a),
   FOREIGN KEY(Id_cat) REFERENCES categories(Id_cat),
   FOREIGN KEY(id_a) REFERENCES article(id_a)
);
